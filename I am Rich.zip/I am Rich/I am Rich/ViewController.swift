//
//  ViewController.swift
//  I am Rich
//
//  Created by Badma on 25.07.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

