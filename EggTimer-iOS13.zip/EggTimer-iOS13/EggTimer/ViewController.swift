//
//  ViewController.swift
//  EggTimer
//
//  Created by Angela Yu on 08/07/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var boilStatus: UILabel!
    @IBOutlet weak var cookingProgressBar: UIProgressView!
    var player : AVAudioPlayer!
    var totalTime = 0
    var secondsPassed = 0
    var timer = Timer()
    let eggTimes = ["Soft" : 3, "Medium" : 4, "Hard" : 7]
    
    @IBAction func hardnessSelected(_ sender: UIButton) {
        timer.invalidate()
        let hardness = sender.currentTitle!
        totalTime = eggTimes[hardness]!
        boilStatus.text = hardness
        cookingProgressBar.progress = 0.0
        secondsPassed = 0
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
    }
    @objc func updateTimer() {
        if totalTime > secondsPassed {
            secondsPassed += 1
            let percentageProgress = Float(secondsPassed) / Float(totalTime)
            cookingProgressBar.progress = percentageProgress
        } else {
            timer.invalidate()
            boilStatus.text = "Done!"
            playSound()
        }
    }
    func playSound() {
        let url = Bundle.main.url(forResource: "alarm_sound", withExtension: "mp3")
        player = try! AVAudioPlayer(contentsOf: url!)
        player.play()
                
    }
}
