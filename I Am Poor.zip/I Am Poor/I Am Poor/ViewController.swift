//
//  ViewController.swift
//  I Am Poor
//
//  Created by Badma on 26.07.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

